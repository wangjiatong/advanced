<?php
namespace Codeception\Step;

use Codeception\Step;

class Action extends Step
{
}
