<?php 

class SimpleAdminGroupCest 
{
    /**
     * @group admin
     */
    function testAdminGroup()
    {

    }

}