<?php
\Codeception\Util\Autoload::addNamespace('CliGuy', __DIR__.DIRECTORY_SEPARATOR.'_steps');
