<html>
<body>
<form action="/form/complex" method="POST" enctype="multipart/form-data">
    <label for="avatar">Avatar</label>
    <input type="file" id="avatar" name="avatar" />
    <input type="submit" value="Submit" />
</form>
</body>
</html>