<?php
$I = new CliGuy($scenario);
$I->am('developer who likes testing');
$I->wantTo('generate sample Suite');
$I->lookForwardTo('have a better tests categorization');

$I->amInPath('tests/data/sandbox');
$I->executeCommand('bootstrap --empty src/FooBar --namespace FooBar');
$I->executeCommand('generate:suite house HouseGuy -c src/FooBar');
$I->seeFileFound('house.suite.yml', 'src/FooBar/tests');
$I->expect('guy class is generated');
$I->seeInThisFile('actor: HouseGuy');
$I->seeInThisFile('- \FooBar\Helper\House');
$I->seeFileFound('House.php', 'src/FooBar/tests/_support/Helper');
$I->seeInThisFile('namespace FooBar\Helper;');

$I->expect('suite is not created due to dashes');
$I->executeCommand('generate:suite invalid-dash-suite');
$I->seeInShellOutput('contains invalid characters');
