<?php

namespace Fixtures\Prophecy;

class WithFinalMethod
{
    final public function finalImplementation()
    {
    }
}
